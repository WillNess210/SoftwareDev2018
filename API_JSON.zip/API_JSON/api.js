//https://blog.logrocket.com/setting-up-a-restful-api-with-node-js-and-postgresql-d96d6fc892d8






const express = require('express');
const bodyParser = require('body-parser');
const app = express();
const port = 3000;
const db = require('./queries')

app.use(bodyParser.json());

app.use(
  bodyParser.urlencoded({
    extended: true,
  })
);


//var router = express.Router();

//https://stackoverflow.com/questions/18310394/no-access-control-allow-origin-node-apache-port-issue
/*
app.use(function (req, res, next) {

    // Website you wish to allow to connect
    res.setHeader('Access-Control-Allow-Origin', '*');

    // Request methods you wish to allow
    res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS, PUT, PATCH, DELETE');
});
*/

app.use(function(req, res, next) {
  res.header("Access-Control-Allow-Origin", "*");
  res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
  res.header('Access-Control-Allow-Methods', 'GET, POST, OPTIONS, PUT, PATCH, DELETE');
  next();
});

app.get('/', (request, response) => {
  //response.sendFile(__dirname + "/test.html");
  response.send('Beginning');
});

app.get('/recipes', db.getRecipe);
app.post('/recipes', db.makeRecipe);
app.get('/recipes/:id', db.getRecipeByID);
app.put('/recipes/:id', db.editRecipeSteps);
app.delete('/recipes/:id', db.deleteRecipe);
app.get('/ingredients', db.getIngredients);
app.get('/ingredients:id', db.getIngredientsByID);
app.put('/ingredients/name/:id', db.editIngredientName);
app.put('/ingredients/amt/:id', db.editIngredientAmt);
app.post('/ingredients', db.addIngredient);
app.delete('/ingredients/:id', db.deleteIngredient);
app.post('/users', db.addUser);
app.delete('/users/:id', db.deleteUser);
app.put('/users/:id', db.editUserEmail);
app.get('/users', db.getUsers);
app.get('/users/:id', db.getUsersByID);

app.listen(port, () => {
  console.log(`App running on port ${port}.`)
})






//app.listen(3000);


//module.exports = app;